---
name: "✨ 功能建议 / Feature Request"
about: 为游戏提出一个新想法
title: "[Feature] "
labels: enhancement
assignees: ''
---

## 你的建议
简明描述你希望增加的功能。

## 使用场景
这个功能解决什么问题 / 提升什么体验？

## 替代方案
你是否考虑过其他实现方式？

## 附加信息
参考图、相关链接、设计草图等。
